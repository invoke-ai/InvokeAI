InvokeAI

Project homepage: https://github.com/invoke-ai/InvokeAI

Installation on Windows:
 You may need to enable Windows Long Paths to install InvokeAI. If you're not
 sure what this is, you almost certainly need to do this. Simply double-click the
 "WinLongPathsEnabled.reg" file located in this directory, and approve the Windows
 warnings. Note that you will need to have admin privileges in order to do this.
 
 Then double-click the 'install.bat' file (while keeping it inside the invokeAI folder).

Installation on Linux and Mac:
 Please open the terminal, and run './install.sh' (while keeping it inside the invokeAI folder).

After installation, please run the 'invoke.bat' file (on Windows) or 'invoke.sh' file (on Linux/Mac) to start InvokeAI.
