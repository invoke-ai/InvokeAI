InvokeAI

Project homepage: https://github.com/invoke-ai/InvokeAI

Installation on Windows:
    NOTE: You might need to enable Windows Long Paths. If you're not sure,
    then you almost certainly need to. Simply double-click the 'WinLongPathsEnabled.reg'
    file. Note that you will need to have admin privileges in order to
    do this.

    Please double-click the 'install.bat' file (while keeping it inside the invokeAI folder).

Installation on Linux and Mac:
    Please open the terminal, and run './install.sh' (while keeping it inside the invokeAI folder).

After installation, please run the 'invoke.bat' file (on Windows) or 'invoke.sh'
file (on Linux/Mac) to start InvokeAI.
